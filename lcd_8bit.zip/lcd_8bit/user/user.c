#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <errno.h>
 
#include <linux/ioctl.h>

//Initialisation
struct ioctl_chr{
	char kernel_buffer[50];	
	unsigned int line_no;	
	unsigned int pos;
};

//IOCTL COMMAND ARGUMENTS

#define CLEAR_DISPLAY 	  		'0'  
#define PRINT_ON_FIRSTLINE  	'1'
#define PRINT_ON_SECONDLINE 	'2'	
#define PRINT_WITH_POSITION 	'3'
#define CURSOR_ON				'4'
#define CURSOR_OFF				'5'


// IOCTL MACROS 

#define IO_CLEAR_DISPLAY    	_IOW( 0xFF, CLEAR_DISPLAY , struct ioctl_chr)
#define IO_PRINT_ON_FIRSTLINE   _IOW( 0xFF, PRINT_ON_FIRSTLINE,  struct ioctl_chr)
#define IO_PRINT_ON_SECONDLINE  _IOW( 0xFF, PRINT_ON_SECONDLINE, struct ioctl_chr)
#define IO_PRINT_WITH_POSITION  _IOW( 0xFF, PRINT_WITH_POSITION, struct ioctl_chr)
#define IO_CURSOR_ON  			_IOW( 0xFF, CURSOR_ON, struct ioctl_chr)
#define IO_CURSOR_OFF  			_IOW( 0XFF, CURSOR_OFF, struct ioctl_chr)

int main ( void )
{
	struct ioctl_chr msg;
	const char io_command;
	char command;
	int fd;
	char k_buffer[50];
	//char *arg[4] = {NULL};
	//arg= (char*)malloc(4*sizeof(char));

	memset(  msg.kernel_buffer, '\0', sizeof(char) * 50 );

	printf( "Input the following : 1.command;\t 2.Display String;\t 3.Line number: 1 or 2\t; 4.String Offset\n");
	printf( "Options: \nCOMMAND: \tClear Display - 0; \tPrint on First line - 1; \tPrint on Second line - 2; \tPrint with Offset - 3; \tCursor ON - 4; \tCursor OFF - 5; \nSTRING TO BE PRINTED: \t Alphanumeric character of your choice\nLINE NUMBER: \t 1 or 2\nCHARACTER OFFSET: \t any integer less than 16" );
	printf("\nString:");
	fgets(k_buffer, sizeof(k_buffer), stdin);
	int f = strlen(k_buffer);
	for (int i=0; i<f-1; i++)
		msg.kernel_buffer[i] = k_buffer[i];
	printf("\nCommand:");
	scanf( "%c", &io_command);
	printf("\nLine number");
	scanf( "%d", &msg.line_no);
	printf("\nCharacter offset:");
	scanf( "%d",&msg.pos);

	//Device Access   
	fd = open("/dev/lcd_8bit", O_WRONLY | O_NDELAY);
	if(fd < 0){
		printf("Unable to open from user space\n");
		perror("/dev/lcd_8bit");
	}
	
	switch( io_command ){
		case (CLEAR_DISPLAY ): // Clears LCD display
			printf("Clear Display \n");	
			if( ioctl( fd, (unsigned int) IO_CLEAR_DISPLAY, &msg) < 0)
				perror("IO_CLEAR_DISPLAY: ERROR \n");
			break;

		case (PRINT_ON_FIRSTLINE ): // Prints on line 1
			printf("Print on First line \n");	
			if( ioctl( fd, (unsigned int) IO_PRINT_ON_FIRSTLINE, &msg) < 0)
				perror("IO_PRINT_ON_FIRSTLINE: ERROR \n");			
			break;

		case (PRINT_ON_SECONDLINE ): // Print on line 2
			printf("Print on Second Line \n");	
			if( ioctl( fd, (unsigned int) IO_PRINT_ON_SECONDLINE, &msg) < 0)
				perror("IO_PRINT_ON_SECONDLINE \n");			
			break;		

		case (PRINT_WITH_POSITION ): // Prints with offset
			printf("Print at Specified Position \n");	
			if( ioctl( fd, (unsigned int) IO_PRINT_WITH_POSITION, &msg) < 0)
				perror("IO_PRINT_WITH_POSITION: ERROR \n");				
			break;

		case (CURSOR_ON ): //Cursor ON
			printf("Cursor on \n");
			if( ioctl( fd, (unsigned int) IO_CURSOR_ON, &msg) < 0)
				perror("IO_CURSOR_ON \n");
			break; 
		
		case (CURSOR_OFF ): // Cursor OFF
			printf("Cursor off \n");
			if( ioctl( fd, (unsigned int) IO_CURSOR_OFF, &msg) < 0)
				perror("IO_CURSOR_OFF \n");
			break;

		default:
			printf("User Level: LCD_8bit Driver: no command requested\n");
			break;
	}

	close(fd);	
	printf("End of User Level Program \n");
}

