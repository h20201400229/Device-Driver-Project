#include <linux/module.h>
#include <linux/version.h>
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/kdev_t.h>
#include <linux/fs.h>
#include <linux/device.h>
#include <linux/cdev.h>

#include <asm/uaccess.h>
#include <linux/init.h>
#include <linux/fcntl.h>
#include <linux/gpio.h>  // linux gpio interface

#include <linux/delay.h> // delay


// LCD Pin Configuration
#define RS_PIN	25  // LCD_RS: 22 (GPIO pin 25)
#define E_PIN	24  // LCD_ENABLE:  18 (GPIO pin 24)

#define DATA_PIN_0	2   // LCD_D0: 3  (GPIO pin 2)
#define DATA_PIN_1	3   // LCD_D1: 5  (GPIO pin 3)
#define DATA_PIN_2	14  // LCD_D2: 8  (GPIO pin 14)
#define DATA_PIN_3	15  // LCD_D3: 10 (GPIO pin 15)
#define DATA_PIN_4	23  // LCD_D4: 16 (GPIO pin 23)
#define DATA_PIN_5	17  // LCD_D5: 11 (GPIO pin 17)
#define DATA_PIN_6	18  // LCD_D6: 12 (GPIO pin 18)
#define DATA_PIN_7	22  // LCD_D7: 15 (GPIO pin 22)


//IOCTL Commands
#define CLEAR_DISPLAY 	  		'0'	
#define PRINT_ON_FIRSTLINE  	'1'
#define PRINT_ON_SECONDLINE 	'2'	
#define PRINT_WITH_POSITION 	'3'
#define CURSOR_ON				'4'
#define CURSOR_OFF				'5'

//Variable initialisation
static dev_t dev_no;	
struct cdev  cdev;	
static struct class *dev_class;
struct ioctl_chr{				
	char kernel_buffer[50];
	unsigned int line_no;
	unsigned int pos;
};


//Function prototypes
static int  gpio_set_base(unsigned int pin);
static void gpio_set( void );
static void gpio_free_base(unsigned int pin);
static void gpio_free_all( void );

static void bit8_data(char data, unsigned int mode);
static void lcd_init(void);

static void print_ops(char * mesg, unsigned int line_no);
static void printWithPos_ops(char * mesg, unsigned int line_no, unsigned int pos);
static void setLinePos_ops(unsigned int line);
static void setPos_ops(unsigned int line, unsigned int pos);

static void lcd_ops(unsigned int cmd);


//Function Defintion
static int gpio_set_base(unsigned int pin)
{
	int ret;

	// Requesting GPIO port
	ret = gpio_request( pin, "GPIO pin request");
	if( ret != 0 )	{
		printk( KERN_DEBUG "Error in requesting GPIO pin %d \n", pin );
		return ret;
	}	
	
	// Exporting GPIO to sysfs to obsere changes in direction of port
	ret = gpio_export( pin, 0);
	if( ret != 0 )	{
		printk( KERN_DEBUG "Error in exporting GPIO pin %d \n", pin );
		return ret;
	}

	// Setting GPIO direction
	ret = gpio_direction_output( pin, 1); 
	if( ret != 0 )	{
		printk( KERN_DEBUG "Error in settign direction to GPIO pin %d \n", pin );	
		return ret;
	}

	// Write value to port
	gpio_set_value( pin, 0);
	
	return 0; 
}

//Setting up all the GPIO pins used
static void gpio_set()
{
	gpio_set_base(RS_PIN); // RS signal 
	gpio_set_base(E_PIN); //Enable pin	

	//Data pins 0 to 7
	gpio_set_base(DATA_PIN_0); 
	gpio_set_base(DATA_PIN_1);
	gpio_set_base(DATA_PIN_2);
	gpio_set_base(DATA_PIN_3);
	gpio_set_base(DATA_PIN_4);
	gpio_set_base(DATA_PIN_5);
	gpio_set_base(DATA_PIN_6);
	gpio_set_base(DATA_PIN_7);
}


static void gpio_free_base(unsigned int pin)
{
	gpio_unexport( pin ) ;	// unexport GPIO from sysfs
	gpio_free( pin );		// deallocating GPIO pins
}

//Deallocating all GPIO pins
static void gpio_free_all()
{
	gpio_free_base(RS_PIN); // RS signal
	gpio_free_base(E_PIN); // Enable

	//Data pins 0 to 7
	gpio_free_base(DATA_PIN_0);
	gpio_free_base(DATA_PIN_1);
	gpio_free_base(DATA_PIN_2);
	gpio_free_base(DATA_PIN_3);
	gpio_free_base(DATA_PIN_4);
	gpio_free_base(DATA_PIN_5);
	gpio_free_base(DATA_PIN_6);
	gpio_free_base(DATA_PIN_7);
}

//Sending command and data to LCD
static void bit8_data(char data, unsigned int mode)
{
	int dt[8] = {0};

	// Part 1.  Upper 4 bit data (from bit 7 to bit 4)
	usleep_range(41*1000, 50*1000); 	// added delay instead of busy checking

	dt[7] = ( (data)&(0x80) ) >> (7) ;
	dt[6] = ( (data)&(0x40) ) >> (6) ;
	dt[5] = ( (data)&(0x20) ) >> (5) ;
	dt[4] = ( (data)&(0x10) ) >> (4) ;
	dt[3] = ( (data)&(0x08) ) >> (3) ;
	dt[2] = ( (data)&(0x04) ) >> (2) ;
	dt[1] = ( (data)&(0x02) ) >> (1) ;
	dt[0] = ( (data)&(0x1) ) ;
	
	//Writing bits to data pin
	gpio_set_value(DATA_PIN_0, dt[0]);
	gpio_set_value(DATA_PIN_1, dt[1]);
	gpio_set_value(DATA_PIN_2, dt[2]);
	gpio_set_value(DATA_PIN_3, dt[3]);
	gpio_set_value(DATA_PIN_4, dt[4]);
	gpio_set_value(DATA_PIN_5, dt[5]);
	gpio_set_value(DATA_PIN_6, dt[6]);
	gpio_set_value(DATA_PIN_7, dt[7]);

	// Set the mode
	gpio_set_value(RS_PIN, mode);
	usleep_range(5, 10);

	// Triggering Enable pin
	gpio_set_value(E_PIN, 1);
	usleep_range(5, 10);
	gpio_set_value(E_PIN, 0);
}

// Commands for lcd Initialisation with delays for execution
static void lcd_init()
{
	usleep_range(41*1000, 50*1000);	// wait for more than 40 ms once the power is on

	bit8_data(0x38, 0);	 // Initialsing 8 bits, 2 line operation at 5x7
	usleep_range(41*1000,50*1000); // wait for than 40 ms

	bit8_data(0X08, 0);	//Display off
	usleep_range(100,200); // wait for more than 100us

	bit8_data(0x01, 0);		//Display clear	
	usleep_range(100,200);

	bit8_data(0x06, 0);		//Entry mode without enabling shift
	usleep_range(100,200);

	bit8_data(0x0F, 0);		// Display on/off control
	usleep_range(100,200);
	
					//~ /* Cursor position */
	//~ lcd_instruction(0x80, 0);		// Instruction 0000
	//~ usleep_range(100,200);
	
}

//Printing operation
static void print_ops(char * mesg, unsigned int line_no)
{
	unsigned int count = 0;

	if(mesg == NULL){
		printk( KERN_DEBUG "No data to print \n");
		return;
	}
	
	switch (line_no)
	{
		case 1: // Print on line 1
			setLinePos_ops( line_no );
			while ( *(mesg) != '\0' )
			{
				if ( count >= 16)
				{
					line_no = 2;
					count = 0;
					break;
				}
				bit8_data( *mesg, 1); // Data mode 
				count++;
				mesg++;
			}
			break;
			
		case 2: //Print on line 2
			setLinePos_ops( line_no );
			while ( *(mesg) != '\0' )
			{
				if ( count >= 16)
				{
					break;
				}
				bit8_data( *mesg, 1); //data mode
				count++;
				mesg++;
			}
			break;
			
		default:
			printk (KERN_DEBUG "Invalid line number\n");
			line_no = 1;
			break;
	}

}

//Print at desired position 
static void printWithPos_ops(char * mesg, unsigned int line_no, unsigned int pos)
{
	unsigned int count = pos;

	if( mesg == NULL ){
		printk( KERN_DEBUG "No data to be printed \n");
		return;
	}
	
	switch (line_no)
	{
		case 1: // Print at 'pos' position in line 1
			setPos_ops( line_no, pos );
			while ( *(mesg) != '\0' )
			{
				if ( count >= 16)
				{
					line_no = 2;
					pos = 0;
					count = 0;
					break;
				}
				bit8_data( *mesg, 1);
				count++;
				mesg++;
			}
			break;
			
		case 2: // Print at 'pos' position in line 2
		setPos_ops( line_no, pos );
		while ( *(mesg) != '\0' )
		{
			if ( count >= 16)
			{
				break;
			}
			bit8_data( *mesg, 1);
			count++;
			mesg++;
		}
		break;
		
		default: // Invalid line number
			printk (KERN_DEBUG "Invalid line number\n");
			line_no = 1;
			break;
	}
}

// Command for setting cursor between 2 line
void setLinePos_ops(unsigned int line)
{
	
	switch (line)
	{
		case 1:
			bit8_data(0x80, 0); // Set cursor in the beginning of line 1
			break;
		
		case 2:
			bit8_data(0xC0, 0); // Setting cursor in line 2
			break;
		
		default: // Invalid request
			printk(KERN_DEBUG "Invalid line number \n");
			break;
	}
	
}

//Command for position 
void setPos_ops(unsigned int line, unsigned int pos)
{
	char cmd;
	
	switch (line)
	{
		case 1: // Command for 'pos' position in line 1
			cmd = 0x80 + (char) pos;
			bit8_data(cmd, 0);
			break;
			
		case 2: // command for 'pos' position in line 2
			cmd = 0xC0 + (char) pos;
			bit8_data(cmd, 0);
			break;
		
		default:  // Invalid line number request
			printk(KERN_DEBUG "Invalid line number \n");
			break;	
	}	
}

//LCD operations
static void lcd_ops(unsigned int cmd)
{
	switch (cmd)
	{
		case 1: // Display Clear
			bit8_data( 0x01, 0); // Command for clearing display
			printk(KERN_INFO "Display cleared\n");
			break;
			
		case 2: // Cursor ON
			bit8_data(0x0F, 0);		// Command for cursor on 
			printk(KERN_INFO "Cursor ON\n");
			break;
			
		case 3: // Cursor OFF
			bit8_data(0x0C, 0);		// command for cursor OFF
			printk(KERN_INFO "Cursor OFF \n");
			break;
		
		case 4://Display oFF
			bit8_data(0x08, 0);		//Command for display OFF
			printk(KERN_INFO "Display OFF \n");
			break;
		
		default: //Invalid operation;
			printk(KERN_DEBUG "Invalid lcd operation request \n");
			break;
	}

}

//File OPerations
static int lcd8_open(struct inode *p_inode, struct file *p_file )
{
	printk(KERN_INFO "Open Operation executed\n");
	return 0;
}
static int lcd8_close(struct inode *p_inode, struct file *p_file )
{
	printk(KERN_INFO "Close operation executed\n\n");
	return 0;
}
static ssize_t lcd8_read(struct file *p_file, char __user *buf, size_t len, loff_t *off)
{
	printk(KERN_INFO "Read operation executed\n");
	return 0;
}
static ssize_t lcd8_write(struct file *p_file, const char __user *buf, size_t len, loff_t *off)
{
	char kernel_buffer[50];
	unsigned long cpylen;

	if( buf == NULL){
		printk( KERN_DEBUG "No data in user buffer \n" );
		return -ENOMEM;
	}

	memset( kernel_buffer, '\0', sizeof(char) * 50 );
	cpylen = (49>(len-1))? len-1:49;

	if(cpylen < 0)
		cpylen = 0;

	if( copy_from_user(&kernel_buffer, buf, cpylen ) ){
		printk( KERN_DEBUG "ERR: Failed to copy from user space buffer \n" );
		return -EFAULT;
	}
	
	lcd_ops(1); //Clears Display

	print_ops( kernel_buffer, 1); // print on the first line by default

	printk(KERN_INFO "Write Operatiom executed\n");

	return len;
}

static long lcd8_ioctl( struct file *p_file, unsigned int io_cmd, unsigned long arg)
{
	struct ioctl_chr io_args;

	printk(KERN_INFO "IOCTL initiated \n");
      	
	if( ((const void *)arg) == NULL){
		printk( KERN_DEBUG "No ioctl command requested \n");
		return -EINVAL;
	}

	memset( io_args.kernel_buffer, '\0', sizeof(char) * 50);

	// Write operation from user space
	if( copy_from_user( &io_args, (const void *)arg, sizeof(io_args) ) ){
		printk( KERN_DEBUG "Failed to write to user buffer \n" );
		return -EFAULT;
	}

	switch( (char) io_cmd ){
		case CLEAR_DISPLAY:
			lcd_ops(1);
			break;

		case PRINT_ON_FIRSTLINE:
			print_ops( io_args.kernel_buffer, 1);
			break;

		case PRINT_ON_SECONDLINE:
			print_ops( io_args.kernel_buffer, 2);
			break;

		case PRINT_WITH_POSITION:
			printWithPos_ops( io_args.kernel_buffer, io_args.line_no, io_args.pos);
			break;

		case CURSOR_ON:
			lcd_ops(2);
			break;

		case CURSOR_OFF:
			lcd_ops(3);
			break;

		default:
			printk(KERN_DEBUG "Invalid command \n");
			return -ENOTTY;
	}
	
	return 0;
}


/* file operation structure */
static struct file_operations lcd8_fops =
{
	.owner = THIS_MODULE,
	.open  =  lcd8_open,
	.release = lcd8_close,
	.read    = lcd8_read,
	.write   = lcd8_write,
	.unlocked_ioctl	= lcd8_ioctl,
};

//init module
static int __init lcd8_init(void)
{
	
	struct device *dev_device;
	

	// dynamically allocate device major number
	if( alloc_chrdev_region( &dev_no, 0 , 1 , "lcd_8bit") < 0) 
	{
		printk( KERN_DEBUG "Failed to allocate major number \n" );
		return -1;
	}

	// create a class structure
	dev_class = class_create( THIS_MODULE, "lcd_8bit" );
	
	if( dev_class == NULL )
	{		
		unregister_chrdev_region( dev_no, 1 );
		printk( KERN_DEBUG "Failed to create Class \n" );
		
		return PTR_ERR( dev_class ) ;
	}
			
	// create a device and registers it with sysfs
	dev_device = device_create( dev_class, NULL, dev_no , NULL, "lcd_8bit" );
	
	if( dev_device == NULL )
	{
		class_destroy( dev_class );
		unregister_chrdev_region( dev_no, 1 );
		printk( KERN_DEBUG "Failed to create device structure \n" );		

		return PTR_ERR( dev_device );
	}

	// initialize a cdev structure
	cdev_init( &cdev, &lcd8_fops);

	// add a character device to the system
	if( cdev_add( &cdev, dev_no , 1) < 0 )
	{
		device_destroy( dev_class, dev_no);
		class_destroy(  dev_class );
		unregister_chrdev_region( dev_no , 1 );
		printk( KERN_DEBUG "Failed to add cdev \n" );		

		return -1;		
	}

	// setup GPIO pins
	gpio_set();

	// initialize LCD once
	lcd_init();

	printk(KERN_INFO "Driver Initialised \n");
	return 0;
}

//EXIT MoDULE
static void __exit lcd8_exit(void)
{
	// turn off LCD display
	lcd_ops(4);

	// remove a cdev from the system
	cdev_del( &cdev);

	// remove device
	device_destroy( dev_class, dev_no );

	// destroy class
	class_destroy( dev_class );	

	// deallocate device major number
	unregister_chrdev_region( dev_no , 1 );

	// releasse GPIO pins
	gpio_free_all();

	printk(KERN_INFO "Driver Exited \n");
}

module_init( lcd8_init );
module_exit( lcd8_exit );


// ************* EXTRA INFO *********************************************

MODULE_LICENSE("GPL");

MODULE_AUTHOR("Deepak Bharadwaj.R and Shri Lakshmi.A");
MODULE_DESCRIPTION("16x2 LCD Controller driver in 8bit mode");


